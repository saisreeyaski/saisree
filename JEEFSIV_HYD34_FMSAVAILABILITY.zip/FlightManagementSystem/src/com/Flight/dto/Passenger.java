package com.Flight.dto;
public class Passenger 
{
  long phone_number;
  String passenger_name;
  int passenger_age;
  String passenger_gender;
  int booking_id;
  public Passenger() {}
  public Passenger(long phone_number, String passenger_name, int passenger_age, int passenger_UIN, String passenger_gender,
		int booking_id) 
  {
	this.phone_number = phone_number;
	this.passenger_name = passenger_name;
	this.passenger_age = passenger_age;
	this.passenger_gender = passenger_gender;
	this.booking_id = booking_id;
  }
public long getPhone_number() {
	return phone_number;
}
public void setPhone_number(long phone_number) {
	this.phone_number = phone_number;
}
public String getPassenger_name() {
	return passenger_name;
}
public void setPassenger_name(String passenger_name) {
	this.passenger_name = passenger_name;
}
public int getPassenger_age() {
	return passenger_age;
}
public void setPassenger_age(int passenger_age) {
	this.passenger_age = passenger_age;
}
public String getpassenger_gender() {
	return passenger_gender;
}
public void setpassenger_gender(String passenger_gender) {
	this.passenger_gender = passenger_gender;
}
public int getBooking_id() {
	return booking_id;
}
public void setBooking_id(int booking_id) {
	this.booking_id = booking_id;
}
}
