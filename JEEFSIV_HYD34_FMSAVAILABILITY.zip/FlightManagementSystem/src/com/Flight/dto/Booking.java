package com.Flight.dto;
import java.util.Date;
public class Booking 
{
  int booking_id;
  int user_id;
  Date booking_date;
  int ticket_cost;
  int passenger_count;
  String booking_state;
  int schedule_flight_id;
  public Booking() {}
  public Booking(int booking_id, int user_id, Date booking_date, int ticket_cost, int passenger_count,
		String booking_state,int schedule_flight_id) {
	this.booking_id = booking_id;
	this.user_id = user_id;
	this.booking_date = booking_date;
	this.ticket_cost = ticket_cost;
	this.passenger_count = passenger_count;
	this.booking_state = booking_state;
	this.schedule_flight_id=schedule_flight_id;
}
public int getBooking_id() {
	return booking_id;
}
public void setBooking_id(int booking_id) {
	this.booking_id = booking_id;
}
public int getUser_id() {
	return user_id;
}
public void setUser_id(int user_id) {
	this.user_id = user_id;
}
public Date getBooking_date() {
	return booking_date;
}
public void setBooking_date(Date booking_date) {
	this.booking_date = booking_date;
}
public int getTicket_cost() {
	return ticket_cost;
}
public void setTicket_cost(int ticket_cost) {
	this.ticket_cost = ticket_cost;
}
public int getPassenger_count() {
	return passenger_count;
}
public void setPassenger_count(int passenger_count) {
	this.passenger_count = passenger_count;
}
public String getBooking_state() {
	return booking_state;
}
public void setBooking_state(String booking_state) {
	this.booking_state = booking_state;
}
public int getSchedule_flight_id() {
	return schedule_flight_id;
}
public void setSchedule_flight_id(int schedule_flight_id) {
	this.schedule_flight_id = schedule_flight_id;
}
}
