package com.Flight.dto;
public class ScheduleFlight 
{
  int schedule_flight_id;
  int available_seats;
  int ticket_cost;
  String sceduleflight_state;
  int flight_number;
  int schedule_id;
  public ScheduleFlight() {}
  public ScheduleFlight(int schedule_flight_id, int available_seats, int ticket_cost, String sceduleflight_state,int flight_number,int schedule_id) 
  {
	this.schedule_flight_id = schedule_flight_id;
	this.available_seats = available_seats;
	this.ticket_cost = ticket_cost;
	this.sceduleflight_state = sceduleflight_state;
	this.flight_number=flight_number;
	this.schedule_id=schedule_id;
}
public int getSchedule_flight_id() {
	return schedule_flight_id;
}
public void setSchedule_flight_id(int schedule_flight_id) {
	this.schedule_flight_id = schedule_flight_id;
}
public int getAvailable_seats() {
	return available_seats;
}
public void setAvailable_seats(int available_seats) {
	this.available_seats = available_seats;
}
public int getTicket_cost() {
	return ticket_cost;
}
public void setTicket_cost(int ticket_cost) {
	this.ticket_cost = ticket_cost;
}
public String getSceduleflight_state() {
	return sceduleflight_state;
}
public void setSceduleflight_state(String sceduleflight_state) {
	this.sceduleflight_state = sceduleflight_state;
}
public int getFlight_number() {
	return flight_number;
}
public void setFlight_number(int flight_number) {
	this.flight_number = flight_number;
}
public int getSchedule_id() {
	return schedule_id;
}
public void setSchedule_id(int schedule_id) {
	this.schedule_id = schedule_id;
}
}
