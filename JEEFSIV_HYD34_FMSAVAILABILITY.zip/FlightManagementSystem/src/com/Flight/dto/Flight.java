package com.Flight.dto;
public class Flight 
{
  int flight_number;
  String flight_model;
  String carrier_name;
  int seat_capacity;
  String flight_state;
  public Flight() {}
  public Flight(int flight_number, String flight_model, String carrier_name, int seat_capacity, String flight_state) 
  {
	this.flight_number = flight_number;
	this.flight_model = flight_model;
	this.carrier_name = carrier_name;
	this.seat_capacity = seat_capacity;
	this.flight_state = flight_state;
  }
public int getFlight_number() {
	return flight_number;
}
public void setFlight_number(int flight_number) {
	this.flight_number = flight_number;
}
public String getFlight_model() {
	return flight_model;
}
public void setFlight_model(String flight_model) {
	this.flight_model = flight_model;
}
public String getCarrier_name() {
	return carrier_name;
}
public void setCarrier_name(String carrier_name) {
	this.carrier_name = carrier_name;
}
public int getSeat_capacity() {
	return seat_capacity;
}
public void setSeat_capacity(int seat_capacity) {
	this.seat_capacity = seat_capacity;
}
public String getFlight_state() {
	return flight_state;
}
public void setFlight_state(String flight_state) {
	this.flight_state = flight_state;
}
}
