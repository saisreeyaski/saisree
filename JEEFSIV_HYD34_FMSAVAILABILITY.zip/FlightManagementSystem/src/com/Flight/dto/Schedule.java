package com.Flight.dto;
public class Schedule 
{
  int schedule_id;
  String source_airport;
  String destination_airport;
  String departure_date_time;
  String arrival_date_time;
  public Schedule() {}
public Schedule(int schedule_id, String source_airport, String destination_airport, String departure_date_time,
		String arrival_date_time) 
{
	this.schedule_id = schedule_id;
	this.source_airport = source_airport;
	this.destination_airport = destination_airport;
	this.departure_date_time = departure_date_time;
	this.arrival_date_time = arrival_date_time;
}
public int getSchedule_id() {
	return schedule_id;
}
public void setSchedule_id(int schedule_id) {
	this.schedule_id = schedule_id;
}
public String getSource_airport() {
	return source_airport;
}
public void setSource_airport(String source_airport) {
	this.source_airport = source_airport;
}
public String getDestination_airport() {
	return destination_airport;
}
public void setDestination_airport(String destination_airport) {
	this.destination_airport = destination_airport;
}
public String getDeparture_date_time() {
	return departure_date_time;
}
public void setDeparture_date_time(String departure_date_time) {
	this.departure_date_time = departure_date_time;
}
public String getArrival_date_time() {
	return arrival_date_time;
}
public void setArrival_date_time(String arrival_date_time) {
	this.arrival_date_time = arrival_date_time;
}
}
