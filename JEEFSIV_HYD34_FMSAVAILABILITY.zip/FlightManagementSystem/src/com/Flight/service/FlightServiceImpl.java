package com.Flight.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.Flight.dao.FlightDao;
import com.Flight.dao.FlightDaoImpl;
import com.Flight.dto.Booking;
import com.Flight.dto.Passenger;
import com.Flight.dto.ScheduleFlight;

public class FlightServiceImpl implements FlightService
{
  FlightDao dao= new FlightDaoImpl();
  public ScheduleFlight checkAvailability(int flight_number, int schedule_id) {
  	return dao.checkAvailability(flight_number, schedule_id);
  }
@Override
public int displayAvailability(ScheduleFlight scheduleflight) {
	// TODO Auto-generated method stub
	return dao.displayAvailability(scheduleflight);
}

public Booking makeBooking(ScheduleFlight scheduleflight) {
	System.out.println("Creating new booking");
	System.out.println("********************");
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the passenger count");
	 int passenger_count=sc.nextInt();
	if(passenger_count>scheduleflight.getAvailable_seats())
	{
		System.out.println("Not enough seats");
	}
	else if (passenger_count == 0) {
		System.out.println("Passenger count must be greater than 0");
	}
	else {
		int user_id = 101;
		Date dateobj = new Date();		
		String booking_date = new SimpleDateFormat("dd/MM/yyyy").format(dateobj); 
		Booking b = new Booking();
		b.setUser_id(123);
		b.setBooking_date(dateobj);
		b.setTicket_cost(scheduleflight.getTicket_cost());
		b.setPassenger_count(passenger_count);
		b.setBooking_state("Pending");
		b.setSchedule_flight_id(scheduleflight.getSchedule_flight_id());
		
		Passenger p[] = new Passenger[passenger_count];
		
		for (int i=1; i<=passenger_count; i++) {
			System.out.println("Enter details for Passenger " + i);
			p[i-1] = new Passenger();
			sc.nextLine();
			System.out.println("Enter Passenger Name");
			String name = sc.nextLine();
			p[i-1].setPassenger_name(name);
			System.out.println("Enter Passenger Age");
			p[i-1].setPassenger_age(sc.nextInt());
			sc.nextLine();
			System.out.println("Enter Passenger Gender");
			String gender = "";
			gender += sc.nextLine();
			p[i-1].setpassenger_gender(gender);
			System.out.println("Enter Passenger Phone Number");
			p[i-1].setPhone_number(sc.nextLong());			
		}
		
		return dao.makeBooking(b, p);
	}
	return null;
}
}
