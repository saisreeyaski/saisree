package com.Flight.service;

import com.Flight.dto.Booking;
import com.Flight.dto.ScheduleFlight;

public interface FlightService 
{
	public ScheduleFlight checkAvailability(int flight_number, int schedule_id);
	public int displayAvailability(ScheduleFlight scheduleflight);
	public Booking makeBooking(ScheduleFlight scheduleflight);
}
