package com.Flight.application;
import com.Flight.dto.Booking;
import com.Flight.dto.ScheduleFlight;
import com.Flight.service.FlightService;
import com.Flight.service.FlightServiceImpl;
public class FlightMainApplication 
{
public static void main(String[] args) 
{
	 ScheduleFlight s1 = null;
	 int available_seats = 0;
	 FlightService service= new FlightServiceImpl();
	 System.out.println("Checking availability for Flight:141 and schedule id:151...");
	 System.out.println("************************************************************");
	 try {
		 s1 = service.checkAvailability(141,  151);
		 available_seats = service.displayAvailability(s1);
	 } catch (Exception e) {
		 System.out.println("No Schedule Flight found for the given criteria");
	 }
	 if (available_seats > 0) {
		 System.out.println("Available seats are: " + available_seats);
		 
		 Booking b1 = service.makeBooking(s1); 
		 System.out.println("Booking ID is: " + b1.getBooking_id());
		 System.out.println("Booking Confirmed.");
	 }
	 else
		 System.out.println("No seats available");
}
}