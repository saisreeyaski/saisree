package com.Flight.utils;

public class FlightDBQueries 
{
  public static String checkAvailQuery="select * from scheduleflight where flight_number=? and schedule_id=?";
  public static String displayAvailQuery="select * from scheduleflight";
  public static String makeBookQuery="select booking_s1.NEXTVAL from dual";
  public static String AddToDBQuery="update scheduleflight set available_seats = available_seats - ? where schedule_flight_id = ?";
}
