package com.Flight.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.Flight.dto.Booking;
import com.Flight.dto.Passenger;
import com.Flight.dto.ScheduleFlight;
import com.Flight.utils.FlightDBQueries;


public class FlightDaoImpl implements FlightDao 
{
	private Connection connection=null;
	private PreparedStatement pst;
	private ResultSet result;
	
	@Override
	public void openConnection() 
	{
		try
		{
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			 String url="jdbc:oracle:thin:@localhost:1521:xe";
			 connection = DriverManager.getConnection(url,"sai","yaski");
	    } catch(ClassNotFoundException | SQLException e)
		{
	    	e.printStackTrace();
		} 
	}

	@Override
	public void close() 
	{
		try {
			connection.close();
		} catch(SQLException e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public ScheduleFlight checkAvailability(int flight_number, int schedule_id) 
	{
		ScheduleFlight s;
		openConnection();
		try
		{
		  pst=connection.prepareStatement(FlightDBQueries.checkAvailQuery);
		  pst.setInt(1,flight_number);
		  pst.setInt(2,schedule_id);
		  result = pst.executeQuery();
		  
		  if(result.next()) {
		  s = new ScheduleFlight(
				  result.getInt(1),
				  result.getInt(2),
				  result.getInt(3),
				  result.getString(4),
				  result.getInt(5),
				  result.getInt(6)
				  );
		  return s;
		  }
		  
		}catch (SQLException e)
		{
			e.printStackTrace();
		}
		close();
		return null;
	}

	@Override
	public int displayAvailability(ScheduleFlight scheduleflight) {
		// TODO Auto-generated method stub
		return scheduleflight.getAvailable_seats();
	}
	
	public Booking makeBooking(Booking booking, Passenger passenger[]) {
		openConnection();
		Booking b = booking;
		int booking_id = 0;
		try {
			pst=connection.prepareStatement(FlightDBQueries.makeBookQuery);
			result = pst.executeQuery();
			if (result.next()) {
				booking_id = result.getInt(1);
			}
			b.setBooking_id(booking_id);
			b.setBooking_state("Confirmed");
			 String qry="insert into booking values(?,?,?,?,?,?,?)";
			  PreparedStatement pst= connection.prepareStatement(qry);
			  pst.setInt(1,b.getBooking_id());
			  pst.setInt(2, b.getUser_id());
			  java.sql.Date sqlDate = new java.sql.Date(b.getBooking_date().getTime());
			  pst.setDate(3,sqlDate);
			  pst.setInt(4,b.getTicket_cost());
			  pst.setInt(5,b.getPassenger_count());
			  pst.setString(6,b.getBooking_state());
			  pst.setInt(7,b.getSchedule_flight_id());			  
			  pst.executeUpdate();
			  
			  pst = connection.prepareStatement(FlightDBQueries.AddToDBQuery);
			  pst.setInt(1, b.getPassenger_count());
			  pst.setInt(2, b.getSchedule_flight_id());
			  pst.execute();
			  System.out.println("Booking added to database");
			  int i = 1;
			  for (Passenger p: passenger) {
				  qry = "insert into passenger values(?,?,?,?,?)";
				  pst= connection.prepareStatement(qry);
				  pst.setString(1,p.getPassenger_name());
				  pst.setInt(2, p.getPassenger_age());
				  pst.setString(3, p.getpassenger_gender());
				  pst.setLong(4, p.getPhone_number());
				  pst.setInt(5, booking_id);
				  pst.execute();
				  System.out.println("Passenger " + i++ + " added to database");
			  }
		} catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return b;
	}
}

