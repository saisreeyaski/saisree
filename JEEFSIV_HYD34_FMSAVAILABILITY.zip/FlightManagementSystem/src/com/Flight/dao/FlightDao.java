package com.Flight.dao;
import com.Flight.dto.Booking;
import com.Flight.dto.Passenger;
import com.Flight.dto.ScheduleFlight;
public interface FlightDao 
{
	 public void openConnection();
	 public void close();
	 public ScheduleFlight checkAvailability(int flight_number, int schedule_id);
	 public int displayAvailability(ScheduleFlight scheduleflight);
	 public Booking makeBooking(Booking booking, Passenger passenger[]);
}
