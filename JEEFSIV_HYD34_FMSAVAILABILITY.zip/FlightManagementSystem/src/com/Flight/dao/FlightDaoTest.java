package com.Flight.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.Flight.dto.ScheduleFlight;

public class FlightDaoTest {
   
	FlightDao fd;
	FlightDaoImpl fl;
	ScheduleFlight sf;
	
	
	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCheckAvailability() {
		fail("Not yet implemented");
		assertEquals(sf,fd.checkAvailability(149, 159));
	}
}
